<?
//  $user = $_POST['user'];
//  $email = $_POST['email'];
//  $password = $_POST['password'];

// //  Database connection using php
// $conn = new mysqli('localhost','root','','minerp');
// if($conn->connect_error){
//     die('Connection Failed : '.$conn->connect_error);
// }else{
//     $stmt = $conn->prepare("insert into registration(user,email,password) values(?,?,?)");
//     $stmt->bind_param("sss",$user,$email,$password);
//     $stmt->execute();
//     echo "Login Successfully.....";
//     $stmt->close();
//     $conn->close();

// }

$host = "localhost";
$username = "root";
$password = "";
$database = "mysqltojson";

$connect = mysqli_connect($host,$username,$password,$database);
$sql = "SELECT * FROM logininfo";
$results = mysqli_query($connect,$sql); 
$json_array = array();

while($data = mysqli_fetch_assoc($results)){
    $json_array[] = $data;
}
echo json_encode($json_array)
?>

